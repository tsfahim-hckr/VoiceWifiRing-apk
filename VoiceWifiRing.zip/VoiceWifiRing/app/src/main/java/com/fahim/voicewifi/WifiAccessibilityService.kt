package com.fahim.voicewifi
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class WifiAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var pending = false
        @Volatile var until = 0L
        fun request(c: Context) {
            pending = true; until = System.currentTimeMillis() + 10000
            c.startActivity(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
    private val h = Handler(Looper.getMainLooper())

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!pending) return
        if (System.currentTimeMillis() > until) { pending = false; return }
        val root = rootInActiveWindow ?: return
        val sw = findWifiSwitch(root) ?: return
        pending = false
        if (!sw.isChecked) clickNode(sw)
        h.postDelayed({ performGlobalAction(GLOBAL_ACTION_BACK) }, 1200)
    }
    override fun onInterrupt() {}

    private fun findWifiSwitch(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (label in listOf("Wi-Fi", "Wi‑Fi", "WiFi", "ওয়াই")) {
            for (n in root.findAccessibilityNodeInfosByText(label)) {
                var p: AccessibilityNodeInfo? = n
                repeat(4) {
                    p?.let { x -> findCheckable(x)?.let { return it } }
                    p = p?.parent
                }
            }
        }
        return null
    }
    private fun findCheckable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isCheckable) return n
        for (i in 0 until n.childCount) n.getChild(i)?.let { c -> findCheckable(c)?.let { return it } }
        return null
    }
    private fun clickNode(n: AccessibilityNodeInfo) {
        var p: AccessibilityNodeInfo? = n
        while (p != null) { if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return; p = p.parent }
    }
}
