package com.fahim.voicewifi
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val p = getSharedPreferences("p", 0)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }.also { box.addView(it) }
        box.addView(TextView(this).apply { text = "Voice WiFi & Ring"; textSize = 26f })
        box.addView(TextView(this).apply {
            text = "\nSetup:\n1) Start dao (mic permission dao)\n2) Accessibility on koro (WiFi auto-on er jonno)\n3) Battery: Unrestricted koro\n\nCommand:\n• \"ON WIFI\" / \"ওয়াইফাই অন\"\n• \"Ring Bajaw\" / \"রিং বাজাও\"\n• \"Stop\" / \"থামো\" = ring bondho\n"
        })
        box.addView(CheckBox(this).apply {
            text = "WiFi off hole 2 minute por auto on"; isChecked = p.getBoolean("auto", true)
            setOnCheckedChangeListener { _, v -> p.edit().putBoolean("auto", v).apply() }
        })
        btn("▶ Start listening") {
            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
            requestPermissions(perms.toTypedArray(), 1)
            startForegroundService(Intent(this, VoiceService::class.java))
        }
        btn("■ Stop") { startService(Intent(this, VoiceService::class.java).setAction("STOP_ALL")) }
        btn("Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("Battery settings") { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
        setContentView(ScrollView(this).apply { addView(box) })
    }
}
