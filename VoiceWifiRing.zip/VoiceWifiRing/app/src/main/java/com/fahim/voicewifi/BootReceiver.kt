package com.fahim.voicewifi
import android.content.*
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        // Android 14+ boot theke mic service start block kore; app ekbar khule Start dite hobe.
    }
}
