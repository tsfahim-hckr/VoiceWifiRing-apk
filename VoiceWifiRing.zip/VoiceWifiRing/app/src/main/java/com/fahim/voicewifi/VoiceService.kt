package com.fahim.voicewifi
import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.net.wifi.WifiManager
import android.os.*
import android.speech.*

class VoiceService : Service() {
    private var sr: SpeechRecognizer? = null
    private val h = Handler(Looper.getMainLooper())
    private var bn = false
    private var player: MediaPlayer? = null
    private var lastCmd = 0L
    private val autoOn = Runnable { enableWifi() }

    private val wifiRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val st = i.getIntExtra(WifiManager.EXTRA_WIFI_STATE, -1)
            if (st == WifiManager.WIFI_STATE_DISABLED && getSharedPreferences("p", 0).getBoolean("auto", true)) {
                h.removeCallbacks(autoOn); h.postDelayed(autoOn, 120000)   // 2 minute por abar on
            } else if (st == WifiManager.WIFI_STATE_ENABLED) h.removeCallbacks(autoOn)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP_RING") { stopRing(); return START_STICKY }
        if (i?.action == "STOP_ALL") { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("v", "Voice", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, VoiceService::class.java).setAction("STOP_RING"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "v").setContentTitle("Voice WiFi & Ring")
            .setContentText("Shunchi: \"ON WIFI\" / \"Ring Bajaw\"").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Ring bondho", stop).build()).build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        registerReceiver(wifiRx, IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION))
        listen()
        return START_STICKY
    }

    private fun listen() {
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) { handle(b); again() }
                override fun onPartialResults(b: Bundle) { handle(b) }
                override fun onError(e: Int) { again() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (bn) "bn-BD" else "en-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true))
        }
    }
    private fun again() { bn = !bn; h.postDelayed({ listen() }, 500) }

    private fun handle(b: Bundle) {
        val t = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.joinToString(" ")?.lowercase() ?: return
        if (System.currentTimeMillis() - lastCmd < 4000) return
        val stop = listOf("stop", "thamo", "bondho", "থামো", "বন্ধ").any { t.contains(it) }
        val ring = listOf("ring", "bajao", "bajaw", "বাজাও", "রিং").any { t.contains(it) }
        val wifi = listOf("wifi", "wi-fi", "wi fi", "ওয়াইফাই", "ওয়াই ফাই").any { t.contains(it) } &&
            (Regex("\\bon\\b").containsMatchIn(t) || t.contains("অন") || t.contains("চালু"))
        when {
            stop -> { lastCmd = System.currentTimeMillis(); stopRing() }
            wifi -> { lastCmd = System.currentTimeMillis(); enableWifi() }
            ring -> { lastCmd = System.currentTimeMillis(); ring() }
        }
    }

    @Suppress("DEPRECATION")
    private fun enableWifi() {
        if (Build.VERSION.SDK_INT < 29) (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled = true
        else WifiAccessibilityService.request(this)
    }

    private fun ring() {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        player?.release()
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            setDataSource(this@VoiceService, uri); isLooping = true; prepare(); start()
        }
        h.postDelayed({ stopRing() }, 60000)
    }
    private fun stopRing() { player?.release(); player = null }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null); stopRing(); sr?.destroy()
        try { unregisterReceiver(wifiRx) } catch (_: Exception) {}
        super.onDestroy()
    }
}
